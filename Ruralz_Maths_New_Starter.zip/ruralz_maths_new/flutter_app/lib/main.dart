import 'package:flutter/material.dart';

void main() => runApp(const RuralzMathsApp());

class RuralzMathsApp extends StatelessWidget {
  const RuralzMathsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ruralz Maths',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF66BB6A)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF4FBF4),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 10), () {
      if (mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()));
      }
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: 130, height: 130,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white,
                boxShadow: [BoxShadow(color: Colors.green.withOpacity(.18), blurRadius: 20)]),
              child: const Icon(Icons.functions, size: 72, color: Color(0xFF43A047)),
            ),
            const SizedBox(height: 24),
            const Text('Ruralz Maths', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Text('Developed by D. K. Chavan sir', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 6),
            const Text('9764081122', style: TextStyle(fontSize: 14)),
            const SizedBox(height: 28),
            const CircularProgressIndicator(),
          ]),
        ),
      );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  static const topics = [
    'Trigonometric Functions', 'Trigonometric Equations', 'Straight Line',
    'Pair of Straight Lines', 'Circle', 'Conic Section', 'Vectors',
    'Three Dimensional Geometry', 'Matrices', 'Determinants',
    'Sequence and Series', 'Probability', 'Statistics', 'Differentiation',
    'Integration', 'Application of Derivatives', 'Application of Integration',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ruralz Maths'), backgroundColor: Colors.green.shade100),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('MHT-CET Mathematics', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Practice PYQs and topic-wise tests.'),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.play_arrow), label: const Text('Quick Test')),
        ]))),
        const SizedBox(height: 10),
        const Text('Topics', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...topics.map((t) => Card(child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.calculate)),
          title: Text(t),
          subtitle: const Text('20 tests planned'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TopicPage(topic: t))),
        ))),
      ]),
    );
  }
}

class TopicPage extends StatelessWidget {
  final String topic;
  const TopicPage({super.key, required this.topic});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(topic)),
    body: ListView.builder(
      padding: const EdgeInsets.all(16), itemCount: 20,
      itemBuilder: (_, i) => Card(child: ListTile(
        leading: CircleAvatar(child: Text('${i + 1}')),
        title: Text('Test ${i + 1}'),
        subtitle: const Text('PYQ / self-generated questions • 20 questions'),
        trailing: const Icon(Icons.play_circle_outline),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuestionPage())),
      )),
    ),
  );
}

class QuestionPage extends StatelessWidget {
  const QuestionPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Test')), 
    body: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Question 1 of 20', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      const Text('Sample question will be loaded from the question bank.', style: TextStyle(fontSize: 19)),
      const SizedBox(height: 24),
      ...['Option A', 'Option B', 'Option C', 'Option D'].map((x) => Card(child: RadioListTile(value: x, groupValue: null, onChanged: (_) {}, title: Text(x)))),
      const Spacer(),
      SizedBox(width: double.infinity, child: FilledButton(onPressed: () {}, child: const Text('Next'))),
    ])),
  );
}
