# Ruralz Maths — New App Starter

Platforms: Android (Flutter) + Web.

Included:
- Light-green Material 3 theme
- 10-second splash screen
- Developer credit and contact number
- MHT-CET Mathematics topic structure
- 20-test structure per topic
- Basic test/question interface
- Standalone web starter

Important: this starter does not yet contain verified MHT-CET PYQs, authentication, Supabase integration, or a production APK. Those are the next implementation stages. The Flutter project can be built for Android and Web with a Flutter SDK environment.
